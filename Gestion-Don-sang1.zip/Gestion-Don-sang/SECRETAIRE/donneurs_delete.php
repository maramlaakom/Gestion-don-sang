<?php
require_once "auth.php";
require_role(['Secretaire','Admin']); //lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';



$id = $_GET['id'];

$stmt = $pdo->prepare("DELETE FROM donneurs WHERE id_donneur=?");
$stmt->execute([$id]);

header("Location: donneurs_list.php?deleted=1");
exit;
?>
