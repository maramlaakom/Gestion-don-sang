<?php
require_once "auth.php";
require_role(['Secretaire','Admin']); //lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';


$groupe = $_GET['groupe'] ?? "";
$ville = $_GET['ville'] ?? "";

$sql = "SELECT * FROM donneurs WHERE 1";
$params = [];

if ($groupe !== "") {
    $sql .= " AND groupe_sanguin = ?";
    $params[] = $groupe;
}
if ($ville !== "") {
    $sql .= " AND ville LIKE ?";
    $params[] = "%".$ville."%";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$donneurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<title>Liste Donneurs</title>
<link rel="stylesheet" href="bootstrap.min.css">
</head>
<body class="container mt-4">

<h3>Liste des Donneurs</h3>

<form method="GET" class="row g-3 mb-4">

    <div class="col-md-4">
        <select name="groupe" class="form-select">
            <option value="">-- Groupe --</option>
            <option>A</option><option>B</option>
            <option>AB</option><option>O</option>
        </select>
    </div>

    <div class="col-md-4">
        <input type="text" name="ville" class="form-control" placeholder="Ville">
    </div>

    <div class="col-md-3">
        <button class="btn btn-primary">Rechercher</button>
    </div>

</form>

<table class="table table-bordered table-striped">
<tr>
    <th>ID</th><th>Nom</th><th>CIN</th><th>Groupe</th><th>Ville</th><th>Actions</th>
</tr>

<?php foreach ($donneurs as $d): ?>
<tr>
    <td><?= $d['id_donneur'] ?></td>
    <td><?= htmlspecialchars($d['nom']) ?></td>
    <td><?= htmlspecialchars($d['cin']) ?></td>
    <td><?= htmlspecialchars($d['groupe_sanguin']." ".$d['rhesus']) ?></td>
    <td><?= htmlspecialchars($d['ville']) ?></td>
    <td>
        <a class="btn btn-info btn-sm" href="donneurs_details.php?id=<?= $d['id_donneur'] ?>">Détails</a>
        <a class="btn btn-warning btn-sm" href="donneurs_edit.php?id=<?= $d['id_donneur'] ?>">Modifier</a>
        <a class="btn btn-danger btn-sm" href="donneurs_delete.php?id=<?= $d['id_donneur'] ?>" 
           onclick="return confirm('Supprimer ?')">Supprimer</a>
    </td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
