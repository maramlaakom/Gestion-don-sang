<?php
require_once "auth.php";
require_role(['Secretaire','Admin']); //lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';



$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM donneurs WHERE id_donneur=?");
$stmt->execute([$id]);
$donneur = $stmt->fetch();

if (!$donneur) {
    die("Donneur introuvable");
}

$stmt2 = $pdo->prepare("SELECT * FROM dons WHERE id_donneur=?");
$stmt2->execute([$id]);
$dons = $stmt2->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
<title>Détails Donneur</title>
<link rel="stylesheet" href="bootstrap.min.css">
</head>
<body class="container mt-4">

<h3>Détails du Donneur</h3>

<div class="card p-3 mb-4">
    <p><strong>Nom :</strong> <?= htmlspecialchars($donneur['nom']) ?></p>
    <p><strong>CIN :</strong> <?= htmlspecialchars($donneur['cin']) ?></p>
    <p><strong>Groupe :</strong> <?= htmlspecialchars($donneur['groupe_sanguin']." ".$donneur['rhesus']) ?></p>
    <p><strong>Ville :</strong> <?= htmlspecialchars($donneur['ville']) ?></p>
</div>

<h4>Historique des Dons</h4>

<table class="table table-bordered">
<tr>
    <th>ID Don</th>
    <th>Centre</th>
    <th>Statut</th>
    <th>Date</th>
</tr>

<?php foreach ($dons as $d): ?>
<tr>
    <td><?= $d['id_don'] ?></td>
    <td><?= $d['id_centre'] ?></td>
    <td><?= $d['statut'] ?></td>
    <td><?= $d['date_don'] ?></td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
