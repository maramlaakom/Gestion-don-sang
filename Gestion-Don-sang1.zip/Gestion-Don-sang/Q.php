<?php
require_once "connexion.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$message = "";

// Traitement du formulaire
if(isset($_POST['submit'])){
    // Sécuriser les entrées
    $cin = htmlspecialchars($_POST['cin']);
   
    
    $groupe_sanguin = $_POST['groupe_sanguin']; // A, B, AB, O
    $rhesus = $_POST['rhesus']; // + ou -

    // Préparer et exécuter l'insertion
    $stmt = $pdo->prepare("
        INSERT INTO donneurs (cin, groupe_sanguin, rhesus)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$cin,$groupe_sanguin, $rhesus]);

    $message = "Donneur ajouté avec succès !";
}
?>

<h3>Ajouter un nouveau donneur</h3>

<?php if($message) echo "<p style='color:green;'>$message</p>"; ?>

<form method="POST">
    <label for="cin">CIN :</label>
    <input type="text" name="cin" id="cin" required><br><br>
    <label for="groupe_sanguin">Groupe Sanguin :</label>
    <select name="groupe_sanguin" id="groupe_sanguin" required>
        <option value="">--Choisir--</option>
        <option value="A">A</option>
        <option value="B">B</option>
        <option value="AB">AB</option>
        <option value="O">O</option>
    </select><br><br>

    <label for="rhesus">Rhesus :</label>
    <select name="rhesus" id="rhesus" required>
        <option value="">--Choisir--</option>
        <option value="+">+</option>
        <option value="-">-</option>
    </select><br><br>

    <input type="submit" name="submit" value="Ajouter Donneur">
</form>

