<?php
session_start();

// إذا ما فماش session نرجعو لل login
if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: ../login.php");
    exit();
}
$role = $_SESSION['role']; // Admin / Médecin / Secrétaire
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <style>
        .menu { background:#333; padding:15px; width:220px; height:100vh; float:left; color:white; }
        .menu a { display:block; padding:10px; color:white; text-decoration:none; margin-bottom:5px; }
        .menu a:hover { background:#555; }
        .content { margin-left:250px; padding:20px; }
    </style>
</head>
<body>

<div class="menu">
    <h2>Menu</h2>

    <?php if ($role == "Admin") : ?>
        <a href="gestion_users.php">Gestion des utilisateurs</a>
        <a href="centres.php">Gestion des centres</a>
        <a href="transfusion.php">Transfusion</a>
        <a href="statistiques.php">Statistiques</a>
    <?php endif; ?>

    <?php if ($role == "Secrétaire") : ?>
        <a href="patients.php">Gestion des patients</a>
        <a href="rendez_vous.php">Rendez-vous</a>
        <a href="transfusion.php">Transfusion</a>
    <?php endif; ?>

    <?php if ($role == "Médecin") : ?>
        <a href="patients.php">Liste des patients</a>
        <a href="dossier_medical.php">Dossier Médical</a>
        <a href="transfusion.php">Transfusion</a>
    <?php endif; ?>

    <a href="logout.php">Déconnexion</a>
</div>

<div class="content">
    <h1>Bienvenue, <?php echo $_SESSION['nom']; ?></h1>
    <p>Votre rôle : <b><?php echo $role ?></b></p>
</div>

</body>
</html>

<?php
/*

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="p-4">

<h2>Bienvenue : <?= htmlspecialchars($role) ?></h2>
<p>Choisissez une action :</p>

<div class="list-group">

    <!-- رابط خاص بالـ Admin -->
    <?php if ($role === "Admin") : ?>
        <a href="../ADMIN/Transfusion.php" class="list-group-item list-group-item-primary">
            🔴 Gestion des Transfusions (Admin)
        </a>

        <a href="../ADMIN/users.php" class="list-group-item list-group-item-primary">
            👥 Gestion des Utilisateurs (Admin)
        </a>
    <?php endif; ?>


    <!-- رابط خاص بالـ Secrétaire -->
    <?php if ($role === "Secrétaire") : ?>
        <a href="../SECRETAIRE/donneurs_list.php" class="list-group-item list-group-item-success">
            📝 Gestion des Donneurs (Secrétaire)
        </a>
    <?php endif; ?>


    <!-- رابط خاص بالـ Médecin -->
    <?php if ($role === "Médecin") : ?>
        <a href="../Medcine/valider_tests.php" class="list-group-item list-group-item-warning">
            🧪 Valider les Tests (Médecin)
        </a>
    <?php endif; ?>

</div>

</body>
</html>
*/
