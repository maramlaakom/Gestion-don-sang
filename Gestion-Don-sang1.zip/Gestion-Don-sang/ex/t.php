<?php
session_start();
$error = "";

if (isset($_POST['login'])) {
    require_once "connexion.php";  // fichier PDO

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($email) && !empty($password)) {

        $sql = "SELECT mot_de_passe FROM utilisateur WHERE email = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);

        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (password_verify($password, $user["mot_de_passe"])) {

                $_SESSION["user_email"] = $email;
                header("Location: UserDashboard.php");
                exit();

            } else {
                $error = "Mot de passe incorrect.";
            }

        } else {
            $error = "Email introuvable.";
        }

    } else {
        $error = "Veuillez remplir tous les champs.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f0f0f0;
        }
        .card {
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .btn-main {
            background-color: #002366;
            color: white;
            font-weight: bold;
        }
        .logo {
            width: 200px;
        }
    </style>
</head>
<body>

<div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="card" style="width: 450px;">

        <div class="text-center mb-3">
            <img src="logo.png" class="logo">
        </div>

        <h3 class="text-center mb-4" style="color:#002366; font-weight:bold;">
            Connexion à votre compte
        </h3>

        <?php if (!empty($error)) { ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php } ?>

        <form method="POST">

            <div class="mb-3">
                <label>Email :</label>
                <input type="email" name="email" class="form-control" placeholder="Entrez votre email" required>
            </div>

            <div class="mb-3">
                <label>Mot de passe :</label>
                <input type="password" name="password" class="form-control" placeholder="Entrez votre mot de passe" required>
            </div>

            <button type="submit" name="login" class="btn btn-main w-100">Se connecter</button>

        </form>

        <div class="text-center mt-3">
            <p>Pas de compte ?
                <a href="register.php" class="text-primary">Créer un compte</a>
            </p>
            <a href="forgot_password.php" class="text-primary">Mot de passe oublié ?</a>
        </div>
    </div>
</div>

</body>
</html>
<?php
session_start();

/*if (!isset($_SESSION["user_email"])) {
    header("Location: login.php");
    exit();
}*/
?>

<h1>Bienvenue <?= $_SESSION["user_email"] ?></h1>
<a href="logout.php">Déconnexion</a>
