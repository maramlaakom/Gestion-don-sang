<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Système DRÄXLMAIER</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f0f0f0;
        }
        .main-card {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            width: 800px;
        }
        .btn-main {
            background-color: #002366;
            color: white;
            font-weight: bold;
        }
        .logo {
            width: 250px;
        }
    </style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="main-card text-center">

        <img src="logo.png" class="logo mb-4">

        <h3 class="mb-4" style="color:#002366; font-weight:bold;">
            "Bienvenue dan "
        </h3>

        <a href="inscription.php" class="btn btn-main w-50 mb-3">
            Continuer vers l'inscription
        </a>

        <a href="quitter.php" class="btn btn-main w-50">
            Quitter
        </a>

    </div>
</div>

</body>
</html>
