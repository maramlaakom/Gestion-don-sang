
<?php
require_once "connexion.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- 1) Récupération des dons VALIDE ---
$dons = $pdo->query("SELECT id_don FROM dons WHERE statut='VALIDE'")
            ->fetchAll(PDO::FETCH_ASSOC);

// --- 2) Traitement du formulaire ---
if (isset($_POST['submit'])) {
    $id_don = $_POST['id_don'];
    $hopital = $_POST['hospital'];
    $date_transfusion = date('Y-m-d');

    // Enregistrer la transfusion
    $stmt = $pdo->prepare("
        INSERT INTO transfusions (id_don, hopital_recepteur, date_transfusion)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$id_don, $hopital, $date_transfusion]);

    // Mettre à jour statut du don
    $stmt2 = $pdo->prepare("UPDATE dons SET statut='UTILISÉ' WHERE id_don=?");
    $stmt2->execute([$id_don]);

    echo "<p style='color:green;'>Transfusion enregistrée avec succès !</p>";
}
?>

<!-- --- Formulaire unique --- -->
<form method="POST">
    <label>Don :</label>
    <select name="id_don" required>
        <option value="">-- Choisir un don --</option>

        <?php foreach($dons as $d){ ?>
            <option value="<?= $d['id_don'] ?>">Don n°<?= $d['id_don'] ?></option>
        <?php } ?>

    </select><br><br>

    <label>Hospital :</label>
    <input type="text" name="hospital" required><br><br>

    <input type="submit" name="submit" value="Transfuser">
</form>


