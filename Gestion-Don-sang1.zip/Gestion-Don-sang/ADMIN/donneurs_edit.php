<?php
require_once "auth.php";
require_role(['Secretaire','Admin']); //lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';


$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM donneurs WHERE id_donneur = ?");
$stmt->execute([$id]);
$donneur = $stmt->fetch();

if (!$donneur) {
    die("Donneur introuvable");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sql = "UPDATE donneurs SET nom=?, cin=?, groupe_sanguin=?, rhesus=?, ville=? WHERE id_donneur=?";
    $pdo->prepare($sql)->execute([
        $_POST['nom'], $_POST['cin'], $_POST['groupe_sanguin'],
        $_POST['rhesus'], $_POST['ville'], $id
    ]);

    header("Location: donneurs_list.php?updated=1");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Modifier Donneur</title>
<link rel="stylesheet" href="bootstrap.min.css">
</head>
<body class="container mt-4">

<h3>Modifier Donneur</h3>

<form method="POST" class="row g-3">

    <div class="col-md-6">
        <label class="form-label">Nom</label>
        <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($donneur['nom']) ?>">
    </div>

    <div class="col-md-6">
        <label class="form-label">CIN</label>
        <input type="text" name="cin" class="form-control" value="<?= htmlspecialchars($donneur['cin']) ?>">
    </div>

    <div class="col-md-6">
        <label class="form-label">Groupe</label>
        <select name="groupe_sanguin" class="form-select">
            <option <?= $donneur['groupe_sanguin']=="A"?"selected":"" ?>>A</option>
            <option <?= $donneur['groupe_sanguin']=="B"?"selected":"" ?>>B</option>
            <option <?= $donneur['groupe_sanguin']=="AB"?"selected":"" ?>>AB</option>
            <option <?= $donneur['groupe_sanguin']=="O"?"selected":"" ?>>O</option>
        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Rhesus</label>
        <select name="rhesus" class="form-select">
            <option <?= $donneur['rhesus']=="+"?"selected":"" ?>>+</option>
            <option <?= $donneur['rhesus']=="-"?"selected":"" ?>>-</option>
        </select>
    </div>

    <div class="col-12">
        <label class="form-label">Ville</label>
        <input type="text" name="ville" class="form-control" value="<?= htmlspecialchars($donneur['ville']) ?>">
    </div>

    <button class="btn btn-warning">Mettre à jour</button>
</form>

</body>
</html>
