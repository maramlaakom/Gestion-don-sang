<?php
// classes/Database.php
class Database {
    private static $instance = null;
    private $pdo;

    // Le constructeur est privé pour empêcher l'instanciation directe
    private function __construct() {
        // 1. Inclure la configuration
        require_once dirname(__DIR__) . '/includes/config.php';
        
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME;
        
        try {
            // 2. Créer l'objet PDO
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Erreur de connexion : " . $e->getMessage());
        }
    }

    // 3. Méthode statique pour obtenir l'instance unique
    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // 4. Méthode publique pour obtenir l'objet PDO lui-même
    public function getConnection() {
        return $this->pdo;
    }
}
?>