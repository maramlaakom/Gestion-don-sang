<?php
// classes/User.php
class User {
    private static $pdo;

    public function __construct() {
        // Récupère l'instance PDO via la classe Database Singleton
        self::$pdo = Database::getInstance()->getConnection();
    }

    // Méthode pour récupérer TOUS les utilisateurs
    public static function getAllUsers() {
        $stmt = self::$pdo->prepare("SELECT id, nom, email FROM utilisateurs");
        $stmt->execute();
        // Utilise FETCH_CLASS pour mapper les résultats à une instance de la classe User (Avancé)
        return $stmt->fetchAll(PDO::FETCH_ASSOC); 
    }

    // Méthode pour insérer un utilisateur (Create)
    public static function insertUser($nom, $email) {
        $sql = "INSERT INTO utilisateurs (nom, email) VALUES (:nom, :email)";
        $stmt = self::$pdo->prepare($sql);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':email', $email);
        return $stmt->execute();
    }
}
?>