
<?php
require_once "connexion.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// 1. Inclure la classe de connexion. On utilise require_once pour être sûr.
require_once 'classes/Database.php'; 

// 2. Inclure la classe Modèle (qui contient la logique de requête)
require_once 'classes/User.php';


$donneurs = $pdo->query("SELECT id_donneur, cin FROM donneurs")->fetchAll();
$centres = $pdo->query("SELECT id_centre FROM centres_collecte")->fetchAll();

if(isset($_POST['submit'])){
    $id_donneur =htmlspecialchars( $_POST['donneur']);
    $id_centre = htmlspecialchars($_POST['centre']);

    $stmt = $pdo->prepare("INSERT INTO dons (id_donneur, id_centre, statut) VALUES (?,?, 'EN STOCK')");
    $stmt->execute([$id_donneur, $id_centre]);

    echo "Don enregistré avec succès !";
}
?>

<form method="POST">
    <label for="donneur">donneur :</label>
    <select name="donneur">
        
    <?php foreach($donneurs as $d){ ?>
        <option value="<?= $d['id_donneur'] ?>">
        Donneur n°<?= $d['id_donneur'] ?>
       </option>

    <?php } ?>
</select><br>



    <label for="centre">centre :</label>
    <select name="centre">
        <?php foreach($centres as $c){ ?>
          <option value="<?= htmlspecialchars($c['id_centre']) ?>">centre <?= htmlspecialchars($c['id_centre']) ?></option>
</option>

        <?php } ?>
    </select><br>

    <input type="submit" name="submit" value="Enregistrer Don">
</form>
