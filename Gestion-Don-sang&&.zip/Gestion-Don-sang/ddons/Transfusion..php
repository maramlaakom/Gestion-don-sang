<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../includes/connexion.php';


$stmt = $pdo->prepare("SELECT id_don FROM dons WHERE statut='VALIDE'");
$stmt->execute();
$dons = $stmt->fetchAll(PDO::FETCH_ASSOC);

$message = "";

if (isset($_POST['submit'])) {
    $id_don = $_POST['id_don'];
    $hopital = $_POST['hospital'];
    $date_transfusion = date('Y-m-d');


    $stmt = $pdo->prepare("
        INSERT INTO transfusions (id_don, hopital_recepteur, date_transfusion)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$id_don, $hopital, $date_transfusion]);

 
    $stmt2 = $pdo->prepare("UPDATE dons SET statut='UTILISÉ' WHERE id_don=?");
    $stmt2->execute([$id_don]);

    echo "<p style='color:green;'>Transfusion enregistrée avec succes !</p>";
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Transfusions</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body >

<div class="container mt-5">

    <div class="card shadow p-4">
        <h3 class="mb-3">Enregistrer une Transfusion</h3>


        <form method="POST">

          
            <div class="mb-3">
                <label class="form-label">Don :</label>
                <select name="id_don" class="form-select" required>
                    <option value="">-- Choisir un don --</option>

                    <?php foreach($dons as $d): ?>
                        <option value="<?= htmlspecialchars($d['id_don']) ?>">
                            Don n°<?= htmlspecialchars($d['id_don']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

        
            <div class="mb-3">
                <label class="form-label">Hopital :</label>
                <input type="text" name="hospital" class="form-control" required>
            </div>

            <button type="submit" name="submit" class="btn btn-primary w-100">
                Transfuser
            </button>
        </form>
    </div>

</div>

</body>
</html>
