<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require_once __DIR__ . '/../includes/connexion.php';

$message = "";


if (isset($_POST['submit'])) {


    $cin = htmlspecialchars(trim($_POST['cin']));
    $groupe_sanguin = htmlspecialchars($_POST['groupe_sanguin']);
    $rhesus = htmlspecialchars($_POST['rhesus']);
     $n = htmlspecialchars($_POST['nom']);
    $p = htmlspecialchars($_POST['prenom']);


  
     $stmt = $pdo->prepare("
        INSERT INTO donneurs (nom,prenom,cin, groupe_sanguin, rhesus)
        VALUES (?, ?, ?,?, ?)
    ");
    $stmt->execute($n,$p,[$cin,$groupe_sanguin, $rhesus]);

    $message = "Donneur ajouté avec succès !";
}
?> 


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Donneur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow p-4">
        <h3 class="mb-4">Ajouter un nouveau donneur</h3>

   
      

        <form method="POST">
             <div class="mb-3">
                <label for="nom" class="form-label">nom :</label>
                <input type="text" name="nom" id="nom" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="prenom" class="form-label">prenom :</label>
                <input type="text" name="prenom" id="prenom" class="form-control" required>
            </div>
           

            <div class="mb-3">
                <label for="cin" class="form-label">CIN :</label>
                <input type="text" name="cin" id="cin" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="groupe_sanguin" class="form-label">Groupe Sanguin :</label>
                <select name="groupe_sanguin" id="groupe_sanguin" class="form-select" required>
                    <option value="">--Choisir--</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="AB">AB</option>
                    <option value="O">O</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="rhesus" class="form-label">Rhesus :</label>
                <select name="rhesus" id="rhesus" class="form-select" required>
                    <option value="">--Choisir--</option>
                    <option value="+">+</option>
                    <option value="-">-</option>
                </select>
            </div>

            <button type="submit" name="submit" class="btn btn-primary w-100">
                Ajouter Donneur
            </button>

        </form>
    </div>
</div>

</body>
</html>
