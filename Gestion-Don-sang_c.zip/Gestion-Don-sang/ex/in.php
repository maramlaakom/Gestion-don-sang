<?php
require_once '../includes/connexion.php'; 
$error = "";
$success = "";

// Récupération des centres depuis la BD
$centres = [];
try {
    $stmt = $pdo->query("SELECT id_centre, nom_centre FROM centre");
    $centres = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Erreur chargement centre : " . $e->getMessage();
}

// Traitement formulaire
if (isset($_POST['submit'])) {
    $nom = $_POST['nom'];
    $centre = $_POST['centre'];
    $role = $_POST['role'];
    $password = $_POST['password'];

    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    try {
        $sql = "INSERT INTO utilisateurs (nom, id_centre, role, mot_de_passe_hash, mot_de_passe)
                VALUES (:nom, :centre, :role, :hash, :plain)";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nom' => $nom,
            ':centre' => $centre,
            ':role' => $role,
            ':hash' => $password_hash,
            ':plain' => $password
        ]);

        $success = "Utilisateur ajouté avec succès !";

    } catch (PDOException $e) {
        $error = "Erreur insertion : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription utilisateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background-color: #f0f0f0; }
        .card {
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .btn-custom {
            background-color: #002366;
            color: white;
        }
    </style>
</head>
<body>

<div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="card" style="width: 500px;">

        <h3 class="text-center mb-4" style="color:#002366; font-weight:bold;">Créer un utilisateur</h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST">

            <div class="mb-3">
                <label class="form-label">Nom utilisateur</label>
                <input type="text" name="nom" class="form-control" required>
            </div>

            <!-- Choix centre venant de la BD -->
            <div class="mb-3">
                <label class="form-label">Centre</label>
                <select name="centre" class="form-control" required>
                    <option value="">-- Choisir un centre --</option>

                    <?php foreach ($centres as $c): ?>
                        <option value="<?= $c['id_centre'] ?>">
                            <?= $c['nom_centre'] ?>
                        </option>
                    <?php endforeach; ?>

                </select>
            </div>

            <!-- Rôle -->
            <div class="mb-3">
                <label class="form-label">Rôle</label>
                <select name="role" class="form-control" required>
                    <option value="Admin">Admin</option>
                    <option value="Medecin">Médecin</option>
                    <option value="Secretaire">Secrétaire</option>
                </select>
            </div>

            <!-- Mot de passe -->
            <div class="mb-3">
                <label class="form-label">Mot de passe</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button name="submit" class="btn btn-custom w-100">Créer</button>
        </form>

    </div>
</div>

</body>
</html>
