<?php
define('DB_HOST', 'localhost'); 
define('DB_NAME','gestion_don_sang');    
define('DB_USER', 'dsi21adminS');          
define('DB_PASS', 'dsi21admin');            
?>
