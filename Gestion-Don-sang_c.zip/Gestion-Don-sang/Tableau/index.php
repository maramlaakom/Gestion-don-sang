<?php
session_start();




require_once __DIR__ . '/../includes/connexion.php';

$errors = [];
$stats = [];
$stock_par_groupe = [];
$alertes_critiques = [];

try {
  
    $sql_alertes = "
        SELECT groupe_sanguin, niveau_alerte
        FROM besoins
        WHERE niveau_alerte IN ('URGENT','CRITIQUE')
        ORDER BY FIELD(niveau_alerte, 'CRITIQUE','URGENT')
    ";
    $alertes_critiques = $pdo->query($sql_alertes)->fetchAll(PDO::FETCH_ASSOC);

  
    $sql_stats = "
        SELECT
            (SELECT COUNT(id_donneur) FROM donneurs) AS total_donneurs,
            (SELECT COUNT(id_centre) FROM centres_collecte) AS total_centres,
            (SELECT COUNT(id_don) FROM dons WHERE statut='VALIDE') AS total_dons_valides
    ";
    $stats = $pdo->query($sql_stats)->fetch(PDO::FETCH_ASSOC);

  
    $sql_stock = "
        SELECT CONCAT(d.groupe_sanguin, d.rhesus) AS groupe_complet,
               COUNT(t.id_don) AS quantite_stock
        FROM dons t
        JOIN donneurs d ON t.id_donneur = d.id_donneur
        WHERE t.statut='VALIDE'
        GROUP BY groupe_complet
        ORDER BY quantite_stock DESC
    ";
    $stock_par_groupe = $pdo->query($sql_stock)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $errors[] = "Erreur de base de données: " . htmlspecialchars($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de Bord</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container-fluid pt-4">

    <h2 class="mb-4">Tableau de Bord</h2>


    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?= htmlspecialchars($errors[0]) ?>
        </div>
    <?php endif; ?>

 
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white shadow">
                <div class="card-body">
                    <h3><?= htmlspecialchars($stats['total_donneurs'] ?? '0') ?></h3>
                    <p>Total Donneurs</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white shadow">
                <div class="card-body">
                    <h3><?= htmlspecialchars($stats['total_dons_valides'] ?? '0') ?></h3>
                    <p>Dons Valides</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info text-white shadow">
                <div class="card-body">
                    <h3><?= htmlspecialchars($stats['total_centres'] ?? '0') ?></h3>
                    <p>Centres de Collecte</p>
                </div>
            </div>
        </div>
    </div>

   
    <h3>État du Stock</h3>
    <table class="table table-striped table-hover mb-4">
        <thead>
            <tr>
                <th>Groupe Sanguin</th>
                <th>Quantité</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($stock_par_groupe)): ?>
                <?php foreach ($stock_par_groupe as $stock): ?>
                    <tr>
                        <td><?= htmlspecialchars($stock['groupe_complet']) ?></td>
                        <td><?= htmlspecialchars($stock['quantite_stock']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="2" class="text-center">Aucun stock valide disponible</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

  <h3>Alertes</h3>
    <?php if (!empty($alertes_critiques)): ?>
        <div class="row">
            <?php foreach ($alertes_critiques as $alerte):
                $alert_class = $alerte['niveau_alerte'] === 'CRITIQUE' ? 'alert-danger' : 'alert-warning';
            ?>
                <div class="col-md-4 mb-3">
                    <div class="alert <?= $alert_class ?> shadow">
                        <strong><?= htmlspecialchars($alerte['niveau_alerte']) ?></strong> pour le groupe
                        <span><?= htmlspecialchars($alerte['groupe_sanguin']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-success">Aucune alerte critique ou urgente</div>
    <?php endif; ?>

</div>

</body>
</html>

