<?php
//require_once "auth.php";
//vrequire_role(["Admin", "Médecin"]);//lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';

require_once '../Medcine/auth.php'; 
require_role(["Admin", "Medecin"]);



ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../includes/connexion.php';

$message = "";


$stmt = $pdo->prepare("SELECT id_don FROM dons WHERE statut='EN STOCK'");
$stmt->execute();
$dons = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['valider'])){

    $id_don = htmlspecialchars($_POST['id_don']);
    $est_conforme = (int) $_POST['est_conforme'];

 
    $check = $pdo->prepare("SELECT id_test FROM tests_don WHERE id_don=?");
    $check->execute([$id_don]);

    if($check->rowCount() > 0){

        $stmt = $pdo->prepare("UPDATE tests_don SET est_conforme=? WHERE id_don=?");
        $stmt->execute([$est_conforme, $id_don]);

        $message = "<div class='alert alert-primary'>Test mis à jour pour ce don.</div>";

    } else {

        $stmt = $pdo->prepare("INSERT INTO tests_don (id_don, est_conforme) VALUES (?, ?)");
        $stmt->execute([$id_don, $est_conforme]);

        $message = "<div class='alert alert-success'>Test enregistré pour ce don.</div>";
    }

    
    $statut = $est_conforme ? 'UTILISÉ' : 'REJETÉ';
    $stmt2 = $pdo->prepare("UPDATE dons SET statut=? WHERE id_don=?");
    $stmt2->execute([$statut, $id_don]);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Validation des Tests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body >

<div class="container mt-5">

    <div class="card shadow p-4">
        <h3 class="mb-3">Valider le Test d'un Don</h3>

        

        <form method="POST">

         
            <div class="mb-3">
                <label class="form-label">Don :</label>
                <select name="id_don" class="form-select" required>
                    <option value="">-- Choisir un don --</option>
                    <?php foreach($dons as $d): ?>
                        <option value="<?= htmlspecialchars($d['id_don']) ?>">
                            Don n°<?= htmlspecialchars($d['id_don']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

          
            <div class="mb-3">
                <label class="form-label">Résultat test :</label>
                <input type="text" name="resultat" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Conforme :</label>
                <select name="est_conforme" class="form-select">
                    <option value="1">Oui</option>
                    <option value="0">Non</option>
                </select>
            </div>

            <button type="submit" name="valider" class="btn btn-primary w-100">
                Valider Test
            </button>
        </form>

    </div>
</div>

</body>
</html>
