<!DOCTYPE html>
<?php
require_once "auth.php";
require_role(['Secretaire','Admin']); //lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'];
    $prenom=$_POST ['prenom'];
    $cin = $_POST['cin'];
    $groupe = $_POST['groupe_sanguin'];
    $rhesus = $_POST['rhesus'];
    $ville = $_POST['ville'];

    $sql = "INSERT INTO donneurs (nom,prenom, cin, groupe_sanguin, rhesus, ville)
            VALUES (?, ?, ?, ?, ?,?)";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([$nom, $cin, $groupe, $rhesus, $ville]);
        $message = "Donneur ajouté avec succès.";
    } catch (PDOException $e) {
        $message = "Erreur : " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Ajouter Donneur</title>
<link href="bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

<h3>Ajouter un Donneur</h3>

<?php if ($message): ?>
<div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">

    <div class="col-md-6">
        <label class="form-label">Nom</label>
        <input type="text" name="nom" required class="form-control">
    </div>
    <div class="col-md-6">
        <label class="form-label">prenom</label>
        <input type="text" name="nom" required class="form-control">
    </div>

    <div class="col-md-6">
        <label class="form-label">CIN</label>
        <input type="text" name="cin" required class="form-control">
    </div>

    <div class="col-md-6">
        <label class="form-label">Groupe sanguin</label>
        <select name="groupe_sanguin" required class="form-select">
            <option>A</option><option>B</option>
            <option>AB</option><option>O</option>
        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Rhesus</label>
        <select name="rhesus" required class="form-select">
            <option>+</option><option>-</option>
        </select>
    </div>

    <div class="col-12">
        <label class="form-label">Ville</label>
        <input type="text" name="ville" class="form-control">
    </div>

    <div class="col-12">
        <button class="btn btn-primary">Ajouter</button>
    </div>

</form>
</body>
</html>
