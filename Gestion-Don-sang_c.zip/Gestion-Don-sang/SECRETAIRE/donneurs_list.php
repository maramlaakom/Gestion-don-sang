<?php
require_once "auth.php";
require_role(['Secretaire','Admin']);
require_once '../includes/connexion.php';

$groupe = $_POST['groupe'] ?? "";
$ville = $_POST['ville'] ?? "";

$sql = "SELECT * FROM donneurs WHERE 1";
$params = [];

if ($groupe !== "") {
    $sql .= " AND groupe_sanguin = ?";
    $params[] = $groupe;
}
if ($ville !== "") {
    $sql .= " AND ville LIKE ?";
    $params[] = "%" . $ville . "%";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$donneurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Donneurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

<h3>Liste des Donneurs</h3>

<form method="POST" class="row g-3 mb-4">
    <div class="col-md-4">
        <select name="groupe" class="form-select">
            <option value="">-- Groupe --</option>
            <option>A</option>
            <option>B</option>
            <option>AB</option>
            <option>O</option>
        </select>
    </div>

    <div class="col-md-4">
        <input type="text" name="ville" class="form-control" placeholder="Ville">
    </div>

    <div class="col-md-3">
        <button class="btn btn-primary">Rechercher</button>
    </div>
</form>

<table class="table table-bordered table-striped">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Prénom</th>
        <th>CIN</th>
        <th>Groupe</th>
        <th>Ville</th>
        <th>Actions</th>
    </tr>

    <?php foreach ($donneurs as $d): ?>
    <tr>
        <td><?= $d['id_donneur'] ?></td>
        <td><?= htmlspecialchars($d['nom_donneur']) ?></td>
        <td><?= htmlspecialchars($d['prenom_donneur']) ?></td>
        <td><?= htmlspecialchars($d['cin']) ?></td>
        <td><?= htmlspecialchars($d['groupe_sanguin'] . " " . $d['rhesus']) ?></td>
        <td><?= htmlspecialchars($d['ville']) ?></td>

        <td>
            <!-- Détails -->
            <form method="POST" action="donneurs_details.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $d['id_donneur'] ?>">
                <button type="submit" class="btn btn-info btn-sm">Détails</button>
            </form>

            <!-- Supprimer -->
            <form method="POST" action="donneurs_delete.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $d['id_donneur'] ?>">
                <button type="submit" class="btn btn-danger btn-sm"
                        onclick="return confirm('Supprimer ?')">Supprimer</button>
            </form>

            <!-- Modifier -->
            <form method="POST" action="donneurs_edit.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $d['id_donneur'] ?>">
                <button type="submit" class="btn btn-warning btn-sm">Modifier</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
