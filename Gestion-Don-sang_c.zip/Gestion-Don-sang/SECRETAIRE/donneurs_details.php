<?php
require_once "auth.php";
require_role(['Secretaire','Admin']); //lena 5ater el secritaire wel admin 3andhoum l7a9 bech yod5lou lena 
require_once '../includes/connexion.php';
// require_once "../auth.php"; // Authentification, si nécessaire
// require_role(["SECRETAIRE", "ADMIN"]);
//require_once __DIR__ . '/../includes/connexion.php';

// Récupération de l'ID via POST
$id = $_POST['id'] ?? null; // Vérifie si l'ID est passé via POST

if (!$id) {
    die("ID manquant.");
}

// Préparer la requête pour récupérer les informations du donneur
$stmt = $pdo->prepare("SELECT * FROM donneurs WHERE id_donneur = ?");
$stmt->execute([$id]);
$donneur = $stmt->fetch();

// Vérification que le donneur existe bien
if (!$donneur) {
    die("Donneur introuvable");
}

// Préparer la requête pour récupérer l'historique des dons
$stmt2 = $pdo->prepare("SELECT * FROM dons WHERE id_donneur = ?");
$stmt2->execute([$id]);
$dons = $stmt2->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails Donneur</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="container mt-4">

<h3>Détails du Donneur</h3>

<div class="card p-3 mb-4">
    <p><strong>Nom :</strong> <?= htmlspecialchars($donneur['nom']) ?></p>
    <p><strong>CIN :</strong> <?= htmlspecialchars($donneur['cin']) ?></p>
    <p><strong>Groupe :</strong> <?= htmlspecialchars($donneur['groupe_sanguin'] . " " . $donneur['rhesus']) ?></p>
    <p><strong>Ville :</strong> <?= htmlspecialchars($donneur['ville']) ?></p>
</div>

<h4>Historique des Dons</h4>

<table class="table table-bordered">
    <tr>
        <th>ID Don</th>
        <th>Centre</th>
        <th>Statut</th>
        <th>Date</th>
    </tr>

    <?php foreach ($dons as $d): ?>
    <tr>
        <td><?= htmlspecialchars($d['id_don']) ?></td>
        <td><?= htmlspecialchars($d['id_centre']) ?></td>
        <td><?= htmlspecialchars($d['statut']) ?></td>
        <td><?= htmlspecialchars($d['date_don']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
