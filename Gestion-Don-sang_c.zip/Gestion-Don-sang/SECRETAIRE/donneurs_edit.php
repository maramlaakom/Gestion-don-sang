<?php
session_start();
require_once "auth.php";
require_role(['Secretaire','Admin']); 
require_once '../includes/connexion.php';

// Vérifier si l'ID est fourni
if (!isset($_POST['id']) || empty($_POST['id'])) {
    die("ID manquant.");
}

$id = $_POST['id'];

// --- Récupérer le donneur pour pré-remplir le formulaire ---
$stmt = $pdo->prepare("SELECT * FROM donneurs WHERE id_donneur = ?");
$stmt->execute([$id]);
$donneur = $stmt->fetch();

if (!$donneur) {
    die("Donneur introuvable avec ID: " . htmlspecialchars($id));
}

// --- Si toutes les données du formulaire sont envoyées, faire l'UPDATE ---
if (isset($_POST['nom_donneur'], $_POST['prenom_donneur'], $_POST['cin'], $_POST['groupe_sanguin'], $_POST['rhesus'], $_POST['ville'])) {

    $sql = "UPDATE donneurs 
            SET nom_donneur=?, prenom_donneur=?, cin=?, groupe_sanguin=?, rhesus=?, ville=?
            WHERE id_donneur=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_POST['nom_donneur'],
        $_POST['prenom_donneur'],
        $_POST['cin'],
        $_POST['groupe_sanguin'],
        $_POST['rhesus'],
        $_POST['ville'],
        $id
    ]);

    header("Location: donneurs_list.php?updated=1");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Modifier Donneur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

<h3>Modifier Donneur</h3>

<form method="POST" class="row g-3">
    <input type="hidden" name="id" value="<?= htmlspecialchars($donneur['id_donneur']) ?>">

    <div class="col-md-6">
        <label class="form-label">Nom</label>
        <input type="text" name="nom_donneur" class="form-control" 
               value="<?= htmlspecialchars($donneur['nom_donneur']) ?>" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">Prénom</label>
        <input type="text" name="prenom_donneur" class="form-control"
               value="<?= htmlspecialchars($donneur['prenom_donneur']) ?>" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">CIN</label>
        <input type="number" name="cin" class="form-control"
               value="<?= htmlspecialchars($donneur['cin']) ?>" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">Groupe sanguin</label>
        <select name="groupe_sanguin" class="form-select" required>
            <option <?= $donneur['groupe_sanguin']=="A"?"selected":"" ?>>A</option>
            <option <?= $donneur['groupe_sanguin']=="B"?"selected":"" ?>>B</option>
            <option <?= $donneur['groupe_sanguin']=="AB"?"selected":"" ?>>AB</option>
            <option <?= $donneur['groupe_sanguin']=="O"?"selected":"" ?>>O</option>
        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Rhesus</label>
        <select name="rhesus" class="form-select" required>
            <option <?= $donneur['rhesus']=="+"?"selected":"" ?>>+</option>
            <option <?= $donneur['rhesus']=="-"?"selected":"" ?>>-</option>
        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Ville</label>
        <input type="text" name="ville" class="form-control"
               value="<?= htmlspecialchars($donneur['ville']) ?>" required>
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-warning">Mettre à jour</button>
        <a href="donneurs_list.php" class="btn btn-secondary">Retour à la liste</a>
    </div>
</form>

</body>
</html>
