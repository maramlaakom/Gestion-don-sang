<?php
session_start();
require_once "auth.php";
require_role(['Secretaire','Admin']);
require_once '../includes/connexion.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $ville = $_POST['ville'];

    $id = $_POST['id'];
    $cin = $_POST['cin'];
    $groupe = $_POST['groupe_sanguin'];
    $rhesus = $_POST['rhesus'];

    $sql = "INSERT INTO donneurs (nom_donneur, prenom_donneur, id_donneur, cin, groupe_sanguin, rhesus, ville)
        VALUES (:nom_donneur, :prenom_donneur, :id_donneur, :cin, :groupe_sanguin, :rhesus, :ville)";


    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':nom_donneur', $nom);
    $stmt->bindParam(':prenom_donneur', $prenom);
    $stmt->bindParam(':ville', $ville);
    $stmt->bindParam(':id_donneur', $id);
    $stmt->bindParam(':cin', $cin);
    $stmt->bindParam(':groupe_sanguin', $groupe);
    $stmt->bindParam(':rhesus', $rhesus);

    if ($stmt->execute()) {
        $message = "Nouvelle entrée créée avec succès !";
    } else {
        $message = "Échec de l'insertion !";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ajouter Donneur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<h3>Ajouter un Donneur</h3>

<?php if (!empty($message)) : ?>
    <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">

    <div class="col-md-6">
        <label class="form-label">Nom</label>
        <input type="text" name="nom" required class="form-control">
    </div>

    <div class="col-md-6">
        <label class="form-label">Prénom</label>
        <input type="text" name="prenom" required class="form-control">
    </div>

    <div class="col-md-6">
        <label class="form-label">CIN</label>
        <input type="text" name="cin" required class="form-control">
    </div>

    <div class="col-md-6">
        <label class="form-label">ID</label>
        <input type="text" name="id" required class="form-control">
    </div>
    <div class="col-md-6">
    <label class="form-label">Ville</label>
    <input type="text" name="ville" required class="form-control">
</div>


    <div class="col-md-6">
        <label class="form-label">Groupe sanguin</label>
        <select name="groupe_sanguin" required class="form-select">
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="AB">AB</option>
            <option value="O">O</option>
        </select>
    </div>

    <div class="col-md-6">
        <label class="form-label">Rhesus</label>
        <select name="rhesus" required class="form-select">
            <option value="+">+</option>
            <option value="-">-</option>
        </select>
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Ajouter</button>
        <a href="donneurs_list.php" class="btn btn-secondary">Retour à la liste</a>
    </div>

</form>

</body>
</html>
