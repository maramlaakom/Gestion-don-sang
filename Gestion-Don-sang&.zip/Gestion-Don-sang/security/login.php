
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Connexion</h2>

    <?php if(isset($error)) { ?>
        <?php echo $error; ?>
    <?php } ?>

    <form method="POST">
        <div class="mb-3">
            <label>Nom d'utilisateur</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Mot de passe</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Se connecter</button>
    </form>
</body>
</html>

<?php

session_start();





if (isset($_POST['submit'])) {
    $username = $_POST['username']; 
    $password = $_POST['password'];

    try {
        
        $sql = "SELECT id_utilisateur, role, mot_de_passe FROM utilisateurs 
        WHERE nom_utilisateur = :username";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        $passwordhash = password_hash($user['mot_de_passe'], PASSWORD_DEFAULT);

        if ($user) {
      
            if (password_verify($password, $passwordhash )) {
               
                $_SESSION['id_utilisateur'] = $user['id_utilisateur'];
                $_SESSION['role'] = $user['role'];

               
                if ($user['role'] == 'ADMIN') {
                    header("Location");
                    exit();
                } elseif ($user['role'] == 'SECRETAIRE') {
                    header("Location");
                    exit();
                } elseif ($user['role'] == 'MEDECIN') {
                    header("Location");
                    exit();
                }
            } else {
                $error = "Mot de passe incorrect";
            }
        } else {
            $error = "Utilisateur non trouvé";
        }

    } catch (PDOException $e) {
        $error = "Erreur SQL : " . $e->getMessage();
    }
}