<?php
session_start();

if (!isset($_SESSION['id_utilisateur']) || empty($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/../includes/connexion.php';

$errors = [];
$stats = [];
$stock_par_groupe = [];
$alertes_critiques = [];

try {


    $alertes_critiques = $pdo->query("
        SELECT groupe_sanguin, niveau_alerte
        FROM besoins
        WHERE niveau_alerte IN ('URGENT', 'CRITIQUE')
        ORDER BY FIELD(niveau_alerte, 'CRITIQUE', 'URGENT')
    ")->fetchAll(PDO::FETCH_ASSOC);


    $stats = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM donneurs) AS total_donneurs,
            (SELECT COUNT(*) FROM centres_collecte) AS total_centres,
            (SELECT COUNT(*) FROM dons WHERE statut = 'VALIDE') AS total_dons_valides
    ")->fetch(PDO::FETCH_ASSOC);

 
    $stock_par_groupe = $pdo->query("
        SELECT 
            CONCAT(d.groupe_sanguin, d.rhesus) AS groupe_complet,
            COUNT(t.id_don) AS quantite_stock
        FROM dons t
        JOIN donneurs d ON t.id_donneur = d.id_donneur
        WHERE t.statut = 'VALIDE'
        GROUP BY groupe_complet
        ORDER BY quantite_stock DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    $errors[] = "Erreur BD: Chargement impossible.";

}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de Bord</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
          rel="stylesheet">

</head>
<body>
    <div class="container-fluid pt-4">

        <h2>Tableau de Bord</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($errors[0]) ?></div>
        <?php endif; ?>


        <h3 class="mt-4">Alertes Stock</h3>
        <hr>

        <?php if (!empty($alertes_critiques)): ?>
            <div class="row">
                <?php foreach ($alertes_critiques as $alerte): ?>
                    <?php $alert_class = $alerte['niveau_alerte'] == 'CRITIQUE' ? 'alert-danger' : 'alert-warning'; ?>
                    
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="alert <?= $alert_class ?> shadow">
                            <strong><?= htmlspecialchars($alerte['niveau_alerte']) ?></strong> — Groupe :
                            <span class="fs-4"><?= htmlspecialchars($alerte['groupe_sanguin']) ?></span>
                        </div>
                    </div>

                <?php endforeach; ?>
            </div>

        <?php else: ?>
            <div class="alert alert-success">Le stock est stable. Aucune alerte.</div>
        <?php endif; ?>


        <h3 class="mt-4">Statistiques Clés</h3>
        <hr>

        <div class="row mb-5">

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card bg-primary text-white shadow">
                    <div class="card-body">
                        <h3><?= htmlspecialchars($stats['total_donneurs'] ?? '0') ?></h3>
                        <p>Total Donneurs</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card bg-success text-white shadow">
                    <div class="card-body">
                        <h3><?= htmlspecialchars($stats['total_dons_valides'] ?? '0') ?></h3>
                        <p>Dons Valides</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card bg-info text-white shadow">
                    <div class="card-body">
                        <h3><?= htmlspecialchars($stats['total_centres'] ?? '0') ?></h3>
                        <p>Centres de Collecte</p>
                    </div>
                </div>
            </div>

        </div>


        <h3 class="mt-4">État Détaillé du Stock</h3>
        <hr>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Groupe Sanguin</th>
                        <th>Quantité</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!empty($stock_par_groupe)): ?>
                        <?php foreach ($stock_par_groupe as $stock): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($stock['groupe_complet']) ?></strong></td>
                            <td><?= htmlspecialchars($stock['quantite_stock']) ?></td>
                        </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr><td colspan="2" class="text-center">Aucun stock disponible.</td></tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>

    </div>
</body>
</html>
v